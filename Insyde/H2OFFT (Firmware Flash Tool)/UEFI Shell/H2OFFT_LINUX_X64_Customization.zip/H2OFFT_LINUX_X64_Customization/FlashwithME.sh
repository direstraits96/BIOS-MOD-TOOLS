#!/bin/bash
#Judge input is valid or not
if [ ! -n "$1" ]
then 
  echo "Error:Have not input BIOS image!"
  exit 0
fi

#Inform BMC not to access ME
FLASH_LOG_FILE=flash_log.log

if [ -f "$FLASH_LOG_FILE" ]
then
  rm -f $FLASH_LOG_FILE
fi
echo "==================================================" >> $FLASH_LOG_FILE
echo "Inform BMC not to access ME" >> $FLASH_LOG_FILE
echo "==================================================" >> $FLASH_LOG_FILE
CountCMD=0
ipmitool raw 0x3C 0x4C 0x01 >> $FLASH_LOG_FILE
while [ $? -ne 0 ]
do
  CountCMD = $(($CountCMD + 1))
  if [ $CountCMD > 3 ]
  then
    break;
  fi
  ipmitool raw 0x3C 0x4C 0x01 >> $FLASH_LOG_FILE
done
echo "Waiting......" >> $FLASH_LOG_FILE
sleep 3
echo "==================================================" >> $FLASH_LOG_FILE
echo "Getting status......" >> $FLASH_LOG_FILE
echo "==================================================" >> $FLASH_LOG_FILE
CountCMD=0
ipmitool raw 0x3C 0x4C 0x02 >> $FLASH_LOG_FILE
while [ $? -ne 0 ]
do
  CountCMD = $(($CountCMD + 1))
  if [ $CountCMD > 3 ]
  then
    break;
  fi
  ipmitool raw 0x3C 0x4C 0x02 >> $FLASH_LOG_FILE
done

#Flashing ME & BIOS
echo "==================================================="
echo "Flash with ME Region!"
echo "==================================================="
./h2offt $1 -ALL -SSB -N
		
echo "Flash with ME is finished!"
echo "System must AC power off to have the changes take effect!"
