#!/bin/bash
#Judge input is valid or not
if [ ! -n "$1" ]
then 
  echo "Error:Have not input BIOS image!"
  exit 0
fi

#Inform BMC not to access ME
FLASH_LOG_FILE=flash_log.log

if [ -f "$FLASH_LOG_FILE" ]
then
  rm -f $FLASH_LOG_FILE
fi
echo "==================================================" >> $FLASH_LOG_FILE
echo "Inform BMC not to access ME" >> $FLASH_LOG_FILE
echo "==================================================" >> $FLASH_LOG_FILE
CountCMD=0
ipmitool raw 0x3C 0x4C 0x01 >> $FLASH_LOG_FILE
while [ $? -ne 0 ]
do
  CountCMD = $(($CountCMD + 1))
  if [ $CountCMD > 3 ]
  then
    break;
  fi
  ipmitool raw 0x3C 0x4C 0x01 >> $FLASH_LOG_FILE
done
echo "Waiting......" >> $FLASH_LOG_FILE
sleep 3
echo "==================================================" >> $FLASH_LOG_FILE
echo "Getting status......" >> $FLASH_LOG_FILE
echo "==================================================" >> $FLASH_LOG_FILE
CountCMD=0
ipmitool raw 0x3C 0x4C 0x02 >> $FLASH_LOG_FILE
while [ $? -ne 0 ]
do
  CountCMD = $(($CountCMD + 1))
  if [ $CountCMD > 3 ]
  then
    break;
  fi
  ipmitool raw 0x3C 0x4C 0x02 >> $FLASH_LOG_FILE
done

#Dump the MACs of Phy card
MAC_DUMP_FILE_NAME=mac.txt
MAC_BACK_FILE_NAME=mac_back.txt
PORT_NUMBER=2
PHY_CARD_DEVICE=37D3

if [ -f "$MAC_BACK_FILE_NAME" ]
then
  rm -f $MAC_BACK_FILE_NAME
fi

echo "==================================================" >> $FLASH_LOG_FILE
echo "Dump the Phy card MACs" >> $FLASH_LOG_FILE
echo "==================================================" >> $FLASH_LOG_FILE
for (( port_loop=1; port_loop <= $PORT_NUMBER; port_loop++))
do
  ./eeupdate64e /DEVICE=$PHY_CARD_DEVICE /NIC=$port_loop /MAC_DUMP_FILE >> $FLASH_LOG_FILE 2>&1
  if [ -f "$MAC_DUMP_FILE_NAME" ]
  then
    cat $MAC_DUMP_FILE_NAME >> $MAC_BACK_FILE_NAME
  fi
done

#Flashing ME & BIOS
echo "==================================================="
echo "Flash with ME Region!"
echo "==================================================="
./h2offt $1 -ALL -SSB -N
		
echo "Flash with ME is finished!"
echo "System must AC power off to have the changes take effect!"

#Write MACs of Phy card back
echo "==================================================" >> $FLASH_LOG_FILE
echo "Write back the Phy card MACs" >> $FLASH_LOG_FILE
echo "==================================================" >> $FLASH_LOG_FILE
if [ -f "$MAC_BACK_FILE_NAME" ]
then
  ./eeupdate64e /DEVICE=$PHY_CARD_DEVICE /A $MAC_BACK_FILE_NAME >> $FLASH_LOG_FILE 2>&1
fi
