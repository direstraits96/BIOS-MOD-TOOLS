#!/bin/bash
if [ ! -n "$1" ]
then 
   echo "Error:Have not input BIOS image!"
   exit 0
fi
./h2offt $1 -ALL -SSB -BIOS -N
