Insyde H2OUVE (UEFI Variable Editor) Version 200.00.00.01.
Copyright (c) 2012 - 2018, Insyde Software Corp. All Rights Reserved.
-------------------------------------------------------------------------------

Using command "H2OUVE-S -h" to display help message as the follows:

    USAGE:
	H2OUVE-S [COMMAND]...

    COMMAND:

    #************************************************************************************************************#
    #                                                                                                            #
    #                                                 Common...                                                  #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -? or -h                         # Display Help information                                                #
    #**********************************#*************************************************************************#
    # -fea                             # Report BIOS supported functionalities.                                  #
    #**********************************#*************************************************************************#
    # -uvebf <Enabled|Disabled>        # Enable/Disable H2OUVE functions in BIOS for subsequent boot.            #
    #**********************************#*************************************************************************#
    # -r <File>                        # Dump the BIOS ROM regions (e.g. Variables, Settings, Strings, etc.) to  #
    #                                  # raw file.                                                               #
    #**********************************#*************************************************************************#
    # -l                               # Load default/original settings for BIOS setup utility.                  #
    #                                  # i.e. delete setup and associated variables in BIOS (data section). Same #
    #                                  #  as "Load Default" option under BIOS Setup Utility.                     #
    #**********************************#*************************************************************************#
    # -c                               # Load Custom Setting.                                                    #
    #**********************************#*************************************************************************#
    # -a                               # Load custom settings for BIOS setup utility.                            #
    #                                  # i.e. restore setup variables in BIOS (data section). Same as "Load      #
    #                                  # Customize Default" option under BIOS Setup Utility.                     #
    #**********************************#*************************************************************************#
    # -sc [File]                       # Save custom settings for BIOS setup utility.                            #
    #                                  # i.e. save custom variables in BIOS (data section). Same as "Save        #
    #                                  # Customize Default" option under BIOS Setup Utility.                     #
    #**********************************#*************************************************************************#
    
    #************************************************************************************************************#
    #                                                                                                            #
    #                                              Setup Editor...                                               #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -gs <File> [-all]                # Generate setup utility current setting to file.                         #
    #                                  # (-all: optional, include suppress and grayout setting)                  #
    #**********************************#*************************************************************************#
    # -ss <File>                       # Modify setup utility settings from a configuration file.                #
    #**********************************#*************************************************************************#
    # -gd <File> [-i <BiosImageFile>]  # Dump default setup utility settings (optionally from specified Bios     #
    #                                  # Image File) to a configuration file.                                    #
    #**********************************#*************************************************************************#
    # -sd <File> -i <BiosImageFile>    # Read saved default configuration file and update setup utility default  #
    #                                  # settings in specified Bios File.                                        #
    #**********************************#*************************************************************************#
    #-ms [-h] -fi <Field> -op <Option> # Modify a setup utility setting by field name, and field options.        #
    #   [-i <BiosImageFile>]           # '-h' to show more information.                                          #
    #**********************************#*************************************************************************#
    #-dpw -admin <Password> [-user     # Set default password.                                                   #
    # Password>] [-i <BiosImageFile>]  #                                                                         #
    #**********************************#*************************************************************************#
    # -d40 <-g [File] | -s <File> | -m <Name> <Value> | -l | -c | -b | -t>                                       #
    #**********************************#*************************************************************************#
    #      Modify current SCU settings, additional options:                                                      #
    #**********************************#*************************************************************************#
    #      -g [File]                   # Same as -gs option, but dump to name-value paired file.                 #
    #**********************************#*************************************************************************#
    #      -s <File>                   # Same as -ss option, but with name-value paired file content.            #
    #**********************************#*************************************************************************#
    #      -m [-h] <Name> <Value>      # Modify a setup utility setting by name and value.                       #
    #      [-m <Name> <Value>]...      # '-h' to show more infotmation                                           #
    #**********************************#*************************************************************************#
    #      -l                          # List all item names.                                                    #
    #**********************************#*************************************************************************#
    #      -c                          # Change current settings to default value.                               #
    #**********************************#*************************************************************************#
    #      -b [File]                   # Same as -gs option, but dump boot device list to name-value paired file.#
    #**********************************#*************************************************************************#
    #      -t [File]                   # Same as -gs option, but dump boot type list to name-value paired file.  #
    #**********************************#*************************************************************************#
    # -cdi [File] [-n <Name>]          # Report duplicate items and their locations in BIOS Setup Utility.       #
    # [-i <ImageFile>]                 #                                                                         #
    #**********************************#*************************************************************************#
    # -gstr <File> <-s|-b>             # Dump configuration and browser strings to string-formatted file from    #
    # -i <ImageFile>                   # Bios image file.                                                        #
    #**********************************#*************************************************************************#
    # -sstr <File> <-s|-b>             # Modify setup configuration or setup browser strings from specified      #
    # -i <ImageFile> [-out <ImageFile>]# string-formatted file to Bios Image File.                               #
    #**********************************#*************************************************************************#
    # -gbd <File>                      # Dump current boot device setting to boot-device file.                   #
    #**********************************#*************************************************************************#
    # -sbd <File>                      # Modify current boot device from specified boot-device file.             #
    #**********************************#*************************************************************************#
    # -gbt <File> [-i <BiosImageFile>] # Dump current boot type setting to boot-type file.                       #
    #**********************************#*************************************************************************#
    # -sbt <File> [-i <BiosImageFile>] # Modify current boot type from specified boot-type file.                 #
    #  [-out <ImageFile>]              #                                                                         #
    #**********************************#*************************************************************************#
    # -bfirst <name> [-t]              # Make device to first boot.                                              #
    #**********************************#*************************************************************************#


    #************************************************************************************************************#
    #                                                                                                            #
    #                                             Variable Editor...                                             #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -gv <File> [-i <BiosImageFile>]  # Dump variable information to a variable record file.                    #
    # [-uve] [-n <NAME>] [-g <GUID>]   #                                                                         #
    #**********************************#*************************************************************************#
    # -sv <File> [-i <BiosImageFile>]  # Modify variable with specifies data File.                               #
    # [-out <ImageFile>]               # Update variables from specified variable record file.                   #
    #**********************************#*************************************************************************#
    # -re [-vn <VarName>] [-vg <GUID>] # Remove a variable by name or GUID.                                      #
    #**********************************#*************************************************************************#
    # -rd [-vn <VarName>] [-vg <GUID>] # Read a variable by name or GUID.                                        #
    #**********************************#*************************************************************************#
    # -wt [-vn <VarName>] [-vg <GUID>] # Write a variable by name or GUID.(If doesn't specify Attribute, default #
    # [-attr <Attribute>]              # is 0x7(NV|BS|RT).                                                       #
    #<-by|-wd|-dw|-qw|-blk|-astr|-ustr># by: byte, wd: word, dw: dword, qw: qword, blk: block data(01h 02h ...), #
    # <VarData>                        # astr: ascii string, ustr: unicode string                                #
    #**********************************#*************************************************************************#
    # -csk <Keyfile> [-og <OwnerGUID>] # Verify that the entered key is already present.                         #
    # [-i <BiosImageFile>]             # (Default Guid is 77fa9abd-0359-4d32-bd60-28f4e78f784b)                  #
    #**********************************#*************************************************************************#

    #************************************************************************************************************#
    #                                                                                                            #
    #                                               ITB Feature...                                               #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -dbos                            # Display Boot Order Sequence.                                            #
    #**********************************#*************************************************************************#
    # -cnvs                            # Clean NV Spare data.                                                    #
    #**********************************#*************************************************************************#
    # -cvhc                            # Check Variable Header Continuity.                                       #
    #**********************************#*************************************************************************#
    # -vorv [-count]                   # Variable store Out of Region Verification.                              #
    #**********************************#*************************************************************************#
    # -cvur [-count]                   # Check Variable Usage situation by Reboot.                               #
    #**********************************#*************************************************************************#
    # -cvus [-count]                   # Check Variable Usage situation by Shutdown.                             #
    #**********************************#*************************************************************************#
    # -cvrd [-count] [-th]             # Check Variable Reclamation on Dxe.                                      #
    #**********************************#*************************************************************************#
    # -cvrs [-count]                   # Check Variable Reclamation on Smm.                                      #
    #**********************************#*************************************************************************#
    # -cvrb [-count]                   # Check Variable Reclamation while has Dirty Byte.                        #
    #**********************************#*************************************************************************#
    # -cvsf [-count] [-bc]             # Check Variable fill Setting. (fill 0xFF)                                #
    #**********************************#*************************************************************************#
    # -cvs0 [-count] [-bc]             # Check Variable fill Setting. (fill 0x00)                                #
    #**********************************#*************************************************************************#
    # -cvax [-count N]                 # Check Variable automatic test.                                          #
    #**********************************#*************************************************************************#
    # -cgnv                            # Check GetNextVariableName on RT Service.                                #
    #**********************************#*************************************************************************#
    # -cssr                            # Check Synchronization between SMM and RT SetVariable.                   #
    #**********************************#*************************************************************************#
    # -cvsd                            # Check variable is existing while changing variable State to             #
    #                                  # Deleted_transition in SMM variable service.                             #
    #**********************************#*************************************************************************#
    # -cbov                            # Check BootOrder Variable device number by add and remove.               #
    #**********************************#*************************************************************************#
    # -sipi                            # Send IPI.                                                               #
    #**********************************#*************************************************************************#

    #************************************************************************************************************#
    #                                                                                                            #
    #                                                 Global...                                                  #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -a                               # Auto Reboot.                                                            #
    #**********************************#*************************************************************************#
    
        
SUMMARY:

    1) Command "-a": It's optional, and it can be added in all other command.

    2) Command "-all": It's optional, Generate Setup Utility Setting to file include suppress and grayout setting.

    3) Command "-out": Save as a file, and it can be added to the end of the "si" and "sd" command.
       (If there is no "-out" command, it will be saved directly back to the original image file.)

    4) If modifying action text string, it will be valid after system reboot.

    5) Command "-mc -add": If doesn't set ConfigID in file, it will generate a ConfigID automatically.
       
EXAMPLES:

    1) Report BIOS supported functionalities
        > H2OUVE-S -fea

    2) Enable/Disable H2OUVE functions in BIOS for subsequent boot
        a) Enable H2OUVE functions
            > H2OUVE-S -uvebf Enabled
        b) Disable H2OUVE functions
            > H2OUVE-S -uvebf Disabled

    3) Dump the BIOS ROM regions to raw file
        > H2OUVE-S -r file.txt

    4) Load default/original settings for BIOS setup utility
	> H2OUVE-S -l

    5) Load custom settings for BIOS setup utility
        > H2OUVE-S -c

    6) Generate setup utility current setting to file
        > H2OUVE-S -gs file.txt (-all)

    7) Modify setup utility settings from a configuration file
        > H2OUVE-S -ss file.txt

    8) Dump default setup utility settings to a configuration file
        a) Operation on ROM
            > H2OUVE-S -gd file.txt
        b) Operation on image
            > H2OUVE-S -gd file.txt -i image.fd

    9) Read saved default configuration file and update setup utility default settings in specified Bios File
        a) Modify and Save
            > H2OUVE-S -sd file.txt -i image.fd
        b) Modify and Save as ...
            > H2OUVE-S -sd file.txt -i image.fd -out out.fd

   10) Modify a setup utility setting by field name, and field options
        a) Modify Oneof Question 
            > H2OUVE-S -ms -fi Quick Boot -op Disabled
        b) Modify Boot Order
            > H2OUVE-S -ms -fi Boot Order -op [Boot Order value list]
           ex: 
               > H2OUVE-S -ms -fi Boot Order -op 2 4 56
               (004)[0] Device 1       (002)[0] Device 2
               (002)[1] Device 2  -->  (004)[1] Device 1
               (056)[2] Device 3       (056)[2] Device 3
               
             
        c) Modify Boot Type Order
            > H2OUVE-S -ms -fi Boot Type Order -op [Boot Type Order String list]
           ex: 
              > H2OUVE-S -ms -fi Boot Type Order -op Hard Disk,CD/DVD ROM,USB Storage
                (005)[00] USB Storage             (002)[01] Hard Disk
                (002)[01] Hard Disk   -->         (003)[02] CD/DVD ROM 
                (003)[02] CD/DVD ROM              (005)[00] USB Storage

        d) Modify password
            d-1) Set Password
                 > H2OUVE-S -ms -fi [Password Prompt] -op "" "[NewPassword]"
                ex: 
                   > H2OUVE-S -ms -fi Set Supervisor Password -op "" "123"

            d-2) Modify Password
                 > H2OUVE-S -ms -fi [Password Prompt] -op "[OldPassword]" "[NewPassword]"
                ex: 
                   > H2OUVE-S -ms -fi Set Supervisor Password -op "123" "456"

            d-3) Delete Password
                 > H2OUVE-S -ms -fi [Password Prompt] -op "[OldPassword]" ""
                ex: 
                   > H2OUVE-S -ms -fi Set Supervisor Password -op "123" ""

   11) Read image file, and generate setup(-s) or setup browser(-b) string setting
        a) generate setup string setting
            > H2OUVE-S -gstr file.txt -s -i image.fd
        b) generate setup browser string setting
            > H2OUVE-S -gstr file.txt -b -i image.fd

   12) Modify setup or setup browser strings with specified file
        a) Modify setup string setting
            a-1) Modify and Save
                  > H2OUVE-S -sstr file.txt -s -i image.fd
            a-2) Modify and Save as ...
                  > H2OUVE-S -sstr file.txt -s -i image.fd -out out.fd
        b) Modify setup browser string setting
            b-1) Modify and Save
                  > H2OUVE-S -sstr file.txt -b -i image.fd
            b-2) Modify and Save as ...
                  > H2OUVE-S -sstr file.txt -b -i image.fd -out out.fd
    
   13) Dump current boot device setting to boot-device file
        > H2OUVE-S -gbd file.txt

   14) Modify current boot device from specified boot-device file
        > H2OUVE-S -sbd file.txt

   15) Dump current boot type setting to boot-type file
        a) Operation on ROM
            > H2OUVE-S -gbt file.txt
        b) Operation on image
            > H2OUVE-S -gbt file.txt -i image.fd

   16) Modify current boot type from specified boot-type file
        a) Operation on ROM
            > H2OUVE-S -sbt gbt.txt
        b) Operation on image
            b-1) Modify and Save
                  > H2OUVE-S -sbt file.txt -i image.fd
            b-2) Modify and Save as ...
                  > H2OUVE-S -sbt file.txt -i image.fd -out out.fd

   17) Make device to first boot
        > H2OUVE-S -bfirst "JetFlashTranscend 16GB  "

   18) Dump variable information to a variable record file
        a) Operation on ROM
            > H2OUVE-S -gv file.txt
        b) Operation on image
            > H2OUVE-S -gv file.txt -i image.fd

   19) Update variables from specified variable record file
        a) Operation on ROM
            > H2OUVE-S -sv file.txt
        b) Operation on image
           b-1) Modify and Save
                 > H2OUVE-S -sv file.txt -i image.fd
           b-2) Modify and Save as ...
                 > H2OUVE-S -sv file.txt -i image.fd -out out.fd

   20) Remove a variable by name or GUID
        a) Remove Specific Variable by Name
            > H2OUVE-S -re -vn VariableName
        b) Remove Specific Variable by GUID
            > H2OUVE-S -re -vg 12345678-1234-1234-1234-123456789012
        c) Remove Specific Variable by Name and GUID
            > H2OUVE-S -re -vn VariableName -vg 12345678-1234-1234-1234-123456789012

   21) Display Boot Order Sequence
        > H2OUVE-S -dbos

   22) Clear NV Spare data
        > H2OUVE-S -cnvs

   23) Check Variable Header Continuity
        > H2OUVE-S -cvhc

   24) Variable store Out of Region Verification
        a) Run testing with 1 time
            > H2OUVE-S -vorv
        b) Run testing with specified times
            > H2OUVE-S -vorv -count [times]
           ex:
              > H2OUVE-S -vorv -count 500

   25) Check Variable Usage situation by Reboot
        a) Run testing with 1 time
            > H2OUVE-S -cvur
        b) Run testing with specified times
            > H2OUVE-S -cvur -count [times]
           ex:
              > H2OUVE-S -cvur -count 500

   26) Check Variable Usage situation by Shutdown
        a) Run testing with 1 time
            > H2OUVE-S -cvus
        b) Run testing with specified times
            > H2OUVE-S -cvus -count [times]
           ex:
              > H2OUVE-S -cvus -count 500

   27) Check Variable Reclamation on Dxe
        a) Run testing with 1 time
            > H2OUVE-S -cvrd
        b) Run testing with specified times
            > H2OUVE-S -cvrd -count [times]
           ex:
              > H2OUVE-S -cvrd -count 500
        c) Run testing with specified threshold of reclamation byte
            > H2OUVE-S -cvrd -count [times]
           ex:
              > H2OUVE-S -cvrd -th 2048
        d) Run testing with specified specified times and threshold of reclamation byte
            > H2OUVE-S -cvrd -count [times]
           ex:
              > H2OUVE-S -cvrd -count 500 -th 2048

   28) Check Variable Reclamation on Smm
        a) Run testing with 1 time
            > H2OUVE-S -cvrs
        b) Run testing with specified times
            > H2OUVE-S -cvrs -count [times]
           ex:
              > H2OUVE-S -cvrs -count 500

   29) Check Variable Reclamation while has Dirty Byte
        a) Run testing with 1 time
            > H2OUVE-S -cvrb
        b) Run testing with specified times
            > H2OUVE-S -cvrb -count [times]
           ex:
              > H2OUVE-S -cvrb -count 500

   30) Check Variable fill Setting. (fill 0xFF)
        a) Run testing with 1 time
            a-1) Erase default size
                  > H2OUVE-S -cvsf
            b-2) Erase specified block number
                  > H2OUVE-S -cvsf -bc [number]
                 ex:
                    > H2OUVE-S -cvsf -bc 4
        b) Run testing with specified times
            a-1) Erase default size
                  > H2OUVE-S -cvsf -count [times]
                 ex:
                    > H2OUVE-S -cvsf -count 500
            b-2) Erase specified block number
                  > H2OUVE-S -cvsf -count [times] -bc [number]
                 ex:
                    > H2OUVE-S -cvsf -count 500 -bc 4
            Note:
                 Erase size = Number * ROM_BLOCK_SIZE

   31) Check Variable fill Setting. (fill 0x00)
        a) Run testing with 1 time
            a-1) Erase default size
                  > H2OUVE-S -cvs0
            b-2) Erase specified block number
                  > H2OUVE-S -cvs0 -bc [number]
                 ex:
                    > H2OUVE-S -cvs0 -bc 4
        b) Run testing with specified times
            a-1) Erase default size
                  > H2OUVE-S -cvs0 -count [times]
                 ex:
                    > H2OUVE-S -cvs0 -count 500
            b-2) Erase specified block number
                  > H2OUVE-S -cvs0 -count [times] -bc [number]
                 ex:
                    > H2OUVE-S -cvs0 -count 500 -bc 4
            Note:
                 Erase size = [number] * ROM_BLOCK_SIZE

   32) Check GetNextVariablename on Runtime
        > H2OUVE-S -cgnv

   33) Check Synchronization between Smm and Runtime SetVariable
        > H2OUVE-S -cssr

   34) Check Variable is existing while changing varinable State to Deleted_transition in SMM variable service.
        > H2OUVE-S -cvsd

   35) Send IPI
        > H2OUVE-S -sipi

   36) Auto Reset
        > H2OUVE-S -a   

   37) Set default password
        a) Set admin password to image.fd
            > H2OUVE-S -dpw -admin "123" -i image.fd
        b) Set admin and user password and save as out.fd
            > H2OUVE-S -dpw -admin "123" -user "456" -i image.fd -out out.fd

   38) Read a variable by name or GUID
        a) Read variable by name
            > H2OUVE-S -rd -vn VariableName
        b) Read variable by GUID
            > H2OUVE-S -rd -vg 12345678-1234-1234-1234-123456789012
        c) Read Specific Variable by Name and GUID
            > H2OUVE-S -rd -vn VariableName -vg 12345678-1234-1234-1234-123456789012

   39) Write a variable by name or GUID
        a) Write variable by name with one byte data.
            > H2OUVE-S -wt -vn VariableName -by 0xFF
        b) Write variable by GUID with one byte data.
            > H2OUVE-S -wt -vg 12345678-1234-1234-1234-123456789012 -by 0xFF
        c) Write Specific Variable by Name and GUID with one byte data.
            > H2OUVE-S -wt -vn VariableName -vg 12345678-1234-1234-1234-123456789012 -by 0xFF
        d) Write Specific Variable by Name and GUID with specified data type.
           d-1) Byte 
                 > H2OUVE-S -wt -vn VariableName -vg 12345678-1234-1234-1234-123456789012 -by "0xFF"
           d-2) Word 
                 > H2OUVE-S -wt -vn VariableName -vg 12345678-1234-1234-1234-123456789012 -wd "0xCDEF"
           d-3) Dword
                 > H2OUVE-S -wt -vn VariableName -vg 12345678-1234-1234-1234-123456789012 -dw "0x12345678"
           d-4) Qword
                 > H2OUVE-S -wt -vn VariableName -vg 12345678-1234-1234-1234-123456789012 -qw "0x1234567812345678"
           d-5) Block data
                 > H2OUVE-S -wt -vn VariableName -vg 12345678-1234-1234-1234-123456789012 -blk "01h 02h 03h"
           d-6) Ascii string
                 > H2OUVE-S -wt -vn VariableName -vg 12345678-1234-1234-1234-123456789012 -astr "Ascii String"
           d-7) Unicode string
                 > H2OUVE-S -wt -vn VariableName -vg 12345678-1234-1234-1234-123456789012 -ustr "Unicode String"

   40) Verify that the entered key is already present
        a) Operation on ROM
            > H2OUVE-S -csk keyfile
        b) Operation on image
            > H2OUVE-S -csk keyfile -i image.fd
