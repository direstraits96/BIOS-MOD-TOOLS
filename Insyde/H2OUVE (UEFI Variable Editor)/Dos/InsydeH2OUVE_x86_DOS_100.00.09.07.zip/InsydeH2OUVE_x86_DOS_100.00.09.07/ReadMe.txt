Insyde H2OUVE (UEFI Variable Editor) Version 100.00.09.07.
Copyright (c) 2012 - 2015, Insyde Software Corp. All Rights Reserved.
-------------------------------------------------------------------------------

Using command "H2OUVE-D -h" to display help message as the follows:

    USAGE:
	H2OUVE-D [COMMAND]...

    COMMAND:

    #************************************************************************************************************#
    #                                                                                                            #
    #                                                 Common...                                                  #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -? or -h                         # Display Help information                                                #
    #**********************************#*************************************************************************#
    # -fea                             # Report BIOS supported functionalities.                                  #
    #**********************************#*************************************************************************#
    # -uvebf <Enabled|Disabled>        # Enable/Disable H2OUVE functions in BIOS for subsequent boot.            #
    #**********************************#*************************************************************************#
    # -r <File>                        # Dump the BIOS ROM regions (e.g. Variables, Settings, Strings, etc.) to  #
    #                                  # raw file.                                                               #
    #**********************************#*************************************************************************#
    # -l                               # Load default/original settings for BIOS setup utility.                  #
    #                                  # i.e. delete setup and associated variables in BIOS (data section). Same #
    #                                  #  as "Load Default" option under BIOS Setup Utility.                     #
    #**********************************#*************************************************************************#
    # -c                               # Load Custom Setting.                                                    #
    #**********************************#*************************************************************************#
    # -a                               # Load custom settings for BIOS setup utility.                            #
    #                                  # i.e. restore setup variables in BIOS (data section). Same as "Load      #
    #                                  # Customize Default" option under BIOS Setup Utility.                     #
    #**********************************#*************************************************************************#
    # -sc [File]                       # Save custom settings for BIOS setup utility.                            #
    #                                  # i.e. save custom variables in BIOS (data section). Same as "Save        #
    #                                  # Customize Default" option under BIOS Setup Utility.                     #
    #**********************************#*************************************************************************#
    
    #************************************************************************************************************#
    #                                                                                                            #
    #                                              Setup Editor...                                               #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -gs <File> [-all]                # Generate setup utility current setting to file.                         #
    #                                  # (-all: optional, include suppress and grayout setting)                  #
    #**********************************#*************************************************************************#
    # -ss <File>                       # Modify setup utility settings from a configuration file.                #
    #**********************************#*************************************************************************#
    # -gd <File> [-i <BiosImageFile>]  # Dump default setup utility settings (optionally from specified Bios     #
    #                                  # Image File) to a configuration file.                                    #
    #**********************************#*************************************************************************#
    # -sd <File> -i <BiosImageFile>    # Read saved default configuration file and update setup utility default  #
    #                                  # settings in specified Bios File.                                        #
    #**********************************#*************************************************************************#
    # -ms [-h] -fi <Field> -op <Option># Modify a setup utility setting by field name, and field options.        #
    #  [-fi <Field> -op <Option>]...   # '-h' to show more information.                                          #
    #**********************************#*************************************************************************#
    # -d40 <-g [File] | -s <File> | -m <Name> <Value> | -l | -c | -b | -t>                                       #
    #**********************************#*************************************************************************#
    #      Modify current SCU settings, additional options:                                                      #
    #**********************************#*************************************************************************#
    #      -g [File]                   # Same as -gs option, but dump to name-value paired file.                 #
    #**********************************#*************************************************************************#
    #      -s <File>                   # Same as -ss option, but with name-value paired file content.            #
    #**********************************#*************************************************************************#
    #      -m [-h] <Name> <Value>      # Modify a setup utility setting by name and value.                       #
    #      [-m <Name> <Value>]...      # '-h' to show more infotmation                                           #
    #**********************************#*************************************************************************#
    #      -l                          # List all item names.                                                    #
    #**********************************#*************************************************************************#
    #      -c                          # Change current settings to default value.                               #
    #**********************************#*************************************************************************#
    #      -b [File]                   # Same as -gs option, but dump boot device list to name-value paired file.#
    #**********************************#*************************************************************************#
    #      -t [File]                   # Same as -gs option, but dump boot type list to name-value paired file.  #
    #**********************************#*************************************************************************#
    # -cdi [File] [-n <Name>]          # Report duplicate items and their locations in BIOS Setup Utility.       #
    # [-i <ImageFile>]                 #                                                                         #
    #**********************************#*************************************************************************#
    # -gstr <File> <-s|-b>             # Dump configuration and browser strings to string-formatted file from    #
    # -i <ImageFile>                   # Bios image file.                                                        #
    #**********************************#*************************************************************************#
    # -sstr <File> <-s|-b>             # Modify setup configuration or setup browser strings from specified      #
    # -i <ImageFile> [-out <ImageFile>]# string-formatted file to Bios Image File.                               #
    #**********************************#*************************************************************************#
    # -gbd <File>                      # Dump current boot device setting to boot-device file.                   #
    #**********************************#*************************************************************************#
    # -sbd <File>                      # Modify current boot device from specified boot-device file.             #
    #**********************************#*************************************************************************#
    # -gbt <File> [-i <BiosImageFile>] # Dump current boot type setting to boot-type file.                       #
    #**********************************#*************************************************************************#
    # -sbt <File> [-i <BiosImageFile>] # Modify current boot type from specified boot-type file.                 #
    #  [-out <ImageFile>]              #                                                                         #
    #**********************************#*************************************************************************#
    # -bfirst <name> [-t]              # Make device to first boot.                                              #
    #**********************************#*************************************************************************#


    #************************************************************************************************************#
    #                                                                                                            #
    #                                             Variable Editor...                                             #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -gv <File> [-i <BiosImageFile>]  # Dump variable information to a variable record file.                    #
    #**********************************#*************************************************************************#
    # -sv <File> [-i <BiosImageFile>]  # Modify variable with specifies data File.                               #
    # [-out <ImageFile>]               # Update variables from specified variable record file.                   #
    #**********************************#*************************************************************************#
    # -re [-vn <VarName>] [-vg <GUID>] # Remove a variable by name or GUID.                                      #
    #**********************************#*************************************************************************#

    #************************************************************************************************************#
    #                                                                                                            #
    #                                           MultiConfig Editor...                                            #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -gk <File> [-i <BiosImageFile>]  # Dump BIOS Hotkey settings to a hot-key file.                            #
    #**********************************#*************************************************************************#
    # -mc OPTIONS                      # Multi-Config feature.                                                   #
    #**********************************#*************************************************************************#
    #     The following arguments are the OPTIONS:                                                               #
    #**********************************#*************************************************************************#
    #     -list [-i <ImageFile>]       # List all Multi-Config regions.                                          #
    #**********************************#*************************************************************************#
    #     -gen <File> <-scu|-k>        # Dump the specified config setting to file.                              #
    #     <ConfigID> [-i <ImageFile>]  #                                                                         #
    #**********************************#*************************************************************************#
    #     -add <File> <-scu|-k>        # Add a new config setting to multi-config region from specified file     #
    #     [-i <ImageFile>]             # format.                                                                 #
    #     [-out <ImageFile>]           #                                                                         #
    #**********************************#*************************************************************************#
    #     -mod <File> <-scu|-k>        # Modify config setting to multi-config region from specified file format #
    #     [-i <ImageFile>]             # .                                                                       #
    #     [-out <ImageFile>]           #                                                                         #
    #**********************************#*************************************************************************#
    #     -del <-scu|-k> <ConfigID>    # Delete specified config setting by ConfigID from multi-config region.   #
    #     [-i <ImageFile>]             #                                                                         #
    #     [-out <ImageFile>]           #                                                                         #
    #**********************************#*************************************************************************#
    #     -act <-scu|-k> <ConfigID>    # Activate specified config setting as startup setting.                   #
    #     [-i <ImageFile>]             #                                                                         #
    #     [-out <ImageFile>]           #                                                                         #
    #**********************************#*************************************************************************#
    #     -act clear <-scu|-k>         # Deactivate the specified setting and return to original startup setting #
    #     [-i <ImageFile>]             # .                                                                       #
    #     [-out <ImageFile>]           #                                                                         #
    #**********************************#*************************************************************************#
    #     -post -scu <ConfigID>        # Activate a specified post boot setting by ConfigID for next boot only.  #
    #     [-i <ImageFile>]             #                                                                         #
    #     [-out <ImageFile>]           #                                                                         #
    #**********************************#*************************************************************************#
    #     -post clear -scu             # Deactivate currernt POST Boot setting.                                  #
    #     [-i <ImageFile>]             #                                                                         #
    #     [-out <ImageFile>]           #                                                                         #
    #**********************************#*************************************************************************#
    #     -format <ImageFile>          # Format Multi-Config Region based on ImageFile.                          #
    #     [-i <ImageFile>]             #                                                                         #
    #     [-out <ImageFile>]           #                                                                         #
    #**********************************#*************************************************************************#
    
    #************************************************************************************************************#
    #                                                                                                            #
    #                                               ITB Feature...                                               #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -dbos                            # Display Boot Order Sequence.                                            #
    #**********************************#*************************************************************************#
    # -cnvs                            # Clean NV Spare data.                                                    #
    #**********************************#*************************************************************************#
    # -cvhc                            # Check Variable Header Continuity.                                       #
    #**********************************#*************************************************************************#
    # -vorv [-count]                   # Variable store Out of Region Verification.                              #
    #**********************************#*************************************************************************#
    # -cvur [-count]                   # Check Variable Usage situation by Reboot.                               #
    #**********************************#*************************************************************************#
    # -cvus [-count]                   # Check Variable Usage situation by Shutdown.                             #
    #**********************************#*************************************************************************#
    # -cvrd [-count] [-th]             # Check Variable Reclamation on Dxe.                                      #
    #**********************************#*************************************************************************#
    # -cvrs [-count]                   # Check Variable Reclamation on Smm.                                      #
    #**********************************#*************************************************************************#
    # -cvrb [-count]                   # Check Variable Reclamation while has Dirty Byte.                        #
    #**********************************#*************************************************************************#
    # -cvsf [-count] [-bc]             # Check Variable fill Setting. (fill 0xFF)                                #
    #**********************************#*************************************************************************#
    # -cvs0 [-count] [-bc]             # Check Variable fill Setting. (fill 0x00)                                #
    #**********************************#*************************************************************************#
    # -cgnv                            # Check GetNextVariableName on RT Service.                                #
    #**********************************#*************************************************************************#
    # -cssr                            # Check Synchronization between SMM and RT SetVariable.                   #
    #**********************************#*************************************************************************#
    # -cvsd                            # Check variable is existing while changing variable State to             #
    #                                  # Deleted_transition in SMM variable service.                             #
    #**********************************#*************************************************************************#
    # -cbov                            # Check BootOrder Variable device number by add and remove.               #
    #**********************************#*************************************************************************#
    # -sipi                            # Send IPI.                                                               #
    #**********************************#*************************************************************************#

    #************************************************************************************************************#
    #                                                                                                            #
    #                                                 Global...                                                  #
    #                                                                                                            #
    #**********************************#*************************************************************************#
    #            COMMAND               #                             DESCEIPTION                                 #
    #**********************************#*************************************************************************#
    # -a                               # Auto Reboot.                                                            #
    #**********************************#*************************************************************************#
    
        
SUMMARY:

    1) Command "-a": It's optional, and it can be added in all other command.

    2) Command "-all": It's optional, Generate Setup Utility Setting to file include suppress and grayout setting.

    3) Command "-out": Save as a file, and it can be added to the end of the "si" and "sd" command.
       (If there is no "-out" command, it will be saved directly back to the original image file.)

    4) If modifying action text string, it will be valid after system reboot.

    5) Command "-mc -add": If doesn't set ConfigID in file, it will generate a ConfigID automatically.
       
EXAMPLES:

    1) Report BIOS supported functionalities
        > H2OUVE-D -fea

    2) Enable/Disable H2OUVE functions in BIOS for subsequent boot
        a) Enable H2OUVE functions
            > H2OUVE-D -uvebf Enabled
        b) Disable H2OUVE functions
            > H2OUVE-D -uvebf Disabled

    3) Dump the BIOS ROM regions to raw file
        > H2OUVE-D -r file.txt

    4) Load default/original settings for BIOS setup utility
	> H2OUVE-D -l

    5) Load custom settings for BIOS setup utility
        > H2OUVE-D -c

    6) Generate setup utility current setting to file
        > H2OUVE-D -gs file.txt (-all)

    7) Modify setup utility settings from a configuration file
        > H2OUVE-D -ss file.txt

    8) Dump default setup utility settings to a configuration file
        a) Operation on ROM
            > H2OUVE-D -gd file.txt
        b) Operation on image
            > H2OUVE-D -gd file.txt -i image.fd

    9) Read saved default configuration file and update setup utility default settings in specified Bios File
        a) Modify and Save
            > H2OUVE-D -sd file.txt -i image.fd
        b) Modify and Save as ...
            > H2OUVE-D -sd file.txt -i image.fd -out out.fd

   10) Modify a setup utility setting by field name, and field options
        a) Modify Oneof Question 
            > H2OUVE-D -ms -fi Quick Boot -op Disabled
        b) Modify Boot Order
            > H2OUVE-D -ms -fi Boot Order -op [Boot Order value list]
           ex: 
               > H2OUVE-D -ms -fi Boot Order -op 2 4 56
               (004)[0] Device 1       (002)[0] Device 2
               (002)[1] Device 2  -->  (004)[1] Device 1
               (056)[2] Device 3       (056)[2] Device 3
               
             
        c) Modify Boot Type Order
            > H2OUVE-D -ms -fi Boot Type Order -op [Boot Type Order String list]
           ex: 
              > H2OUVE-D -ms -fi Boot Type Order -op Hard Disk,CD/DVD ROM,USB Storage
                (005)[00] USB Storage             (002)[01] Hard Disk
                (002)[01] Hard Disk   -->         (003)[02] CD/DVD ROM 
                (003)[02] CD/DVD ROM              (005)[00] USB Storage

        d) Modify password
            d-1) Set Password
                 > H2OUVE-D -ms -fi [Password Prompt] -op "" "[NewPassword]"
                ex: 
                   > H2OUVE-D -ms -fi Set Supervisor Password -op "" "123"

            d-2) Modify Password
                 > H2OUVE-D -ms -fi [Password Prompt] -op "[OldPassword]" "[NewPassword]"
                ex: 
                   > H2OUVE-D -ms -fi Set Supervisor Password -op "123" "456"

            d-3) Delete Password
                 > H2OUVE-D -ms -fi [Password Prompt] -op "[OldPassword]" ""
                ex: 
                   > H2OUVE-D -ms -fi Set Supervisor Password -op "123" ""

   11) Read image file, and generate setup(-s) or setup browser(-b) string setting
        a) generate setup string setting
            > H2OUVE-D -gstr file.txt -s -i image.fd
        b) generate setup browser string setting
            > H2OUVE-D -gstr file.txt -b -i image.fd

   12) Modify setup or setup browser strings with specified file
        a) Modify setup string setting
            a-1) Modify and Save
                  > H2OUVE-D -sstr file.txt -s -i image.fd
            a-2) Modify and Save as ...
                  > H2OUVE-D -sstr file.txt -s -i image.fd -out out.fd
        b) Modify setup browser string setting
            b-1) Modify and Save
                  > H2OUVE-D -sstr file.txt -b -i image.fd
            b-2) Modify and Save as ...
                  > H2OUVE-D -sstr file.txt -b -i image.fd -out out.fd
    
   13) Dump current boot device setting to boot-device file
        > H2OUVE-D -gbd file.txt

   14) Modify current boot device from specified boot-device file
        > H2OUVE-D -sbd file.txt

   15) Dump current boot type setting to boot-type file
        a) Operation on ROM
            > H2OUVE-D -gbt file.txt
        b) Operation on image
            > H2OUVE-D -gbt file.txt -i image.fd

   16) Modify current boot type from specified boot-type file
        a) Operation on ROM
            > H2OUVE-D -sbt gbt.txt
        b) Operation on image
            b-1) Modify and Save
                  > H2OUVE-D -sbt file.txt -i image.fd
            b-2) Modify and Save as ...
                  > H2OUVE-D -sbt file.txt -i image.fd -out out.fd

   17) Make device to first boot
        > H2OUVE-D -bfirst "JetFlashTranscend 16GB  "

   18) Dump variable information to a variable record file
        a) Operation on ROM
            > H2OUVE-D -gv file.txt
        b) Operation on image
            > H2OUVE-D -gv file.txt -i image.fd

   19) Update variables from specified variable record file
        a) Operation on ROM
            > H2OUVE-D -sv file.txt
        b) Operation on image
           b-1) Modify and Save
                 > H2OUVE-D -sv file.txt -i image.fd
           b-2) Modify and Save as ...
                 > H2OUVE-D -sv file.txt -i image.fd -out out.fd

   20) Remove a variable by name or GUID
        a) Remove Specific Variable by Name
            > H2OUVE-D -re -vn VariableName
        b) Remove Specific Variable by GUID
            > H2OUVE-D -re -vg 12345678-1234-1234-1234-123456789012
        c) Remove Specific Variable by Name and GUID
            > H2OUVE-D -re -vn VariableName -vg 12345678-1234-1234-1234-123456789012

   21) Generate BIOS Hotkey setting to file
        a) Operation on ROM
            > H2OUVE-D -gk file.txt
        b) Operation on image
            > H2OUVE-D -gk file.txt -i image.fd

   22) List all Multi-Config regions
        a) Operation on ROM
            > H2OUVE-D -mc -list
        b) Operation on image
            > H2OUVE-D -mc -list -i image.fd

   23) Dump the specified config setting to file
        a) Operation on ROM
            a-1) Setup default settting
                  > H2OUVE-D -mc -gen file.txt -scu 1
            a-2) Hotkey setting
                  > H2OUVE-D -mc -gen file.txt -k 1 
        b) Operation on image
            b-1) Setup default settting
                  > H2OUVE-D -mc -gen file.txt -scu 1 -i image.fd
            b-2) Hotkey setting
                  > H2OUVE-D -mc -gen file.txt -k 1 -i image.fd

   24) Add a new config setting to multi-config region from specified file format
        a) Operation on ROM
            a-1) Setup default settting
                  > H2OUVE-D -mc -add file.txt -scu
            a-2) Hotkey setting
                  > H2OUVE-D -mc -add file.txt -k
        b) Operation on image
            b-1) Setup default settting
                  > H2OUVE-D -mc -add file.txt -scu -i image.fd
            b-2) Hotkey setting
                  > H2OUVE-D -mc -add file.txt -k -i image.fd

   25) Modify config setting to multi-config region from specified file format
        a) Operation on ROM
            a-1) Setup default settting
                  > H2OUVE-D -mc -mod file.txt -scu
            a-2) Hotkey setting
                  > H2OUVE-D -mc -mod file.txt -k
        b) Operation on image
            b-1) Setup default settting
                  > H2OUVE-D -mc -mod file.txt -scu -i image.fd
            b-2) Hotkey setting
                  > H2OUVE-D -mc -mod file.txt -k -i image.fd

   26) Delete specified config setting by ConfigID from multi-config region
        a) Operation on ROM
            a-1) Setup default settting
                  > H2OUVE-D -mc -del -scu 1
            a-2) Hotkey setting
                  > H2OUVE-D -mc -del -k 1
        b) Operation on image
            b-1) Setup default settting
                  > H2OUVE-D -mc -del -scu 1 -i image.fd
            b-2) Hotkey setting
                  > H2OUVE-D -mc -del -k 1 -i image.fd

   27) Activate specified config setting as startup setting
        a) Operation on ROM
            a-1) Setup default settting
                  > H2OUVE-D -mc -act -scu 1
            a-2) Hotkey setting
                  > H2OUVE-D -mc -act -k 1
        b) Operation on image
            b-1) Setup default settting
                  > H2OUVE-D -mc -act -scu 1 -i image.fd
            b-2) Hotkey setting
                  > H2OUVE-D -mc -act -k 1 -i image.fd

   28) Deactivate the specified setting and return to original startup setting
        a) Operation on ROM
            a-1) Setup default settting
                  > H2OUVE-D -mc -act clear -scu
            a-2) Hotkey setting
                  > H2OUVE-D -mc -act clear -k
        b) Operation on image
            b-1) Setup default settting
                  > H2OUVE-D -mc -act clear -scu -i image.fd
            b-2) Hotkey setting
                  > H2OUVE-D -mc -act clear -k -i image.fd

   29) Activate a specified post boot setting by ConfigID for next boot only
        a) Operation on ROM
            > H2OUVE-D -mc -post -scu 1
        b) Operation on image
            > H2OUVE-D -mc -post -scu 1 -i image.fd

   30) Deactivate currernt POST Boot setting
        a) Operation on ROM
            > H2OUVE-D -mc -post clear -scu
        b) Operation on image
            > H2OUVE-D -mc -post clear -scu -i image.fd   

   31) Format Multi-Config Region based on ImageFile
        a) Operation on ROM
            > H2OUVE-D -mc -format imageBK.fd
        b) Operation on image
            > H2OUVE-D -mc -format imageBK.fd -i image.fd

   32) Display Boot Order Sequence
        > H2OUVE-D -dbos

   33) Clear NV Spare data
        > H2OUVE-D -cnvs

   34) Check Variable Header Continuity
        > H2OUVE-D -cvhc

   35) Variable store Out of Region Verification
        a) Run testing with 1 time
            > H2OUVE-D -vorv
        b) Run testing with specified times
            > H2OUVE-D -vorv -count [times]
           ex:
              > H2OUVE-D -vorv -count 500

   36) Check Variable Usage situation by Reboot
        a) Run testing with 1 time
            > H2OUVE-D -cvur
        b) Run testing with specified times
            > H2OUVE-D -cvur -count [times]
           ex:
              > H2OUVE-D -cvur -count 500

   37) Check Variable Usage situation by Shutdown
        a) Run testing with 1 time
            > H2OUVE-D -cvus
        b) Run testing with specified times
            > H2OUVE-D -cvus -count [times]
           ex:
              > H2OUVE-D -cvus -count 500

   38) Check Variable Reclamation on Dxe
        a) Run testing with 1 time
            > H2OUVE-D -cvrd
        b) Run testing with specified times
            > H2OUVE-D -cvrd -count [times]
           ex:
              > H2OUVE-D -cvrd -count 500
        c) Run testing with specified threshold of reclamation byte
            > H2OUVE-D -cvrd -count [times]
           ex:
              > H2OUVE-D -cvrd -th 2048
        d) Run testing with specified specified times and threshold of reclamation byte
            > H2OUVE-D -cvrd -count [times]
           ex:
              > H2OUVE-D -cvrd -count 500 -th 2048

   39) Check Variable Reclamation on Smm
        a) Run testing with 1 time
            > H2OUVE-D -cvrs
        b) Run testing with specified times
            > H2OUVE-D -cvrs -count [times]
           ex:
              > H2OUVE-D -cvrs -count 500

   40) Check Variable Reclamation while has Dirty Byte
        a) Run testing with 1 time
            > H2OUVE-D -cvrb
        b) Run testing with specified times
            > H2OUVE-D -cvrb -count [times]
           ex:
              > H2OUVE-D -cvrb -count 500

   41) Check Variable fill Setting. (fill 0xFF)
        a) Run testing with 1 time
            a-1) Erase default size
                  > H2OUVE-D -cvsf
            b-2) Erase specified block number
                  > H2OUVE-D -cvsf -bc [number]
                 ex:
                    > H2OUVE-D -cvsf -bc 4
        b) Run testing with specified times
            a-1) Erase default size
                  > H2OUVE-D -cvsf -count [times]
                 ex:
                    > H2OUVE-D -cvsf -count 500
            b-2) Erase specified block number
                  > H2OUVE-D -cvsf -count [times] -bc [number]
                 ex:
                    > H2OUVE-D -cvsf -count 500 -bc 4
            Note:
                 Erase size = Number * ROM_BLOCK_SIZE

   42) Check Variable fill Setting. (fill 0x00)
        a) Run testing with 1 time
            a-1) Erase default size
                  > H2OUVE-D -cvs0
            b-2) Erase specified block number
                  > H2OUVE-D -cvs0 -bc [number]
                 ex:
                    > H2OUVE-D -cvs0 -bc 4
        b) Run testing with specified times
            a-1) Erase default size
                  > H2OUVE-D -cvs0 -count [times]
                 ex:
                    > H2OUVE-D -cvs0 -count 500
            b-2) Erase specified block number
                  > H2OUVE-D -cvs0 -count [times] -bc [number]
                 ex:
                    > H2OUVE-D -cvs0 -count 500 -bc 4
            Note:
                 Erase size = [number] * ROM_BLOCK_SIZE

   43) Check GetNextVariablename on Runtime
        > H2OUVE-D -cgnv

   44) Check Synchronization between Smm and Runtime SetVariable
        > H2OUVE-D -cssr

   45) Check Variable is existing while changing varinable State to Deleted_transition in SMM variable service.
        > H2OUVE-D -cvsd

   46) Send IPI
        > H2OUVE-D -sipi

   47) Auto Reset
        > H2OUVE-D -a   
