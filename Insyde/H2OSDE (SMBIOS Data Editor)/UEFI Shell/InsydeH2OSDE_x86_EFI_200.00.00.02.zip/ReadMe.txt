Insyde H2OSDE (SMBIOS Data Editor) Version (SEG) 100.00.04.02 
Copyright(c) 2012-2014, Insyde Software Corp. All Rights Reserved.
-------------------------------------------------------------------------------

Using command "H2OSDE-S -H" to display help message as the follows:

    USAGE:
	H2OSDE-S [OPTIONS]...
          or
	H2OSDE-S -F <Image File> <OPTIONS>...

    OPTIONS:
        -?, -H                   - Display Help information
        -L [H=|T=]               - Display DMI/SMBIOS information
        -C                       - SMBIOS Control Clear GPNV  
        -O [File] [H=|T=]        - Output configuration file
        -A [File]                - Apply configuration file
        -G [Handle]              - Save and dump system event log, default Handle = 0
        -I                       - DMI information
        <Type 1> 
        -SM  ["String"]          - Read/[Write] system Manufacturer
        -SP  ["String"]          - Read/[Write] system Product
        -SV  ["String"]          - Read/[Write] system Version
        -SS  ["String"]          - Read/[Write] system Serial Number
        -SU  [UUID|AUTO]         - Read/[Write] system UUID
        -SKU ["String"]          - Read/[Write] system SKU Number
        -SF  ["String"]          - Read/[Write] system Family Name
        <Type 2>
        -BM  ["String"]          - Read/[Write] baseboard Manufacturer
        -BP  ["String"]          - Read/[Write] baseboard Product
        -BV  ["String"]          - Read/[Write] baseboard Version
        -BS  ["String"]          - Read/[Write] baseboard Serial Number
        <Type 3>
        -CM  ["String"]          - Read/[Write] chassis Manufacturer
        -CT  [8-Bit Value]       - Read/[Write] chassis Type
        -CV  ["String"]          - Read/[Write] chassis Version
        -CS  ["String"]          - Read/[Write] chassis Serial Number
        -CA  ["String"]          - Read/[Write] chassis Tag
        -CO  [32-Bit Value]      - Read/[Write] chassis OEM-defined Value
        <Type 11> 
        -OS  [Number] ["String"] - Read/[Write] OEM-String N
	<Customized>
	-DA  ["String"]          - Read/[Write] Asset Tag
	-DS  ["String"]          - Read/[Write] Service Tag
	-DP  ["String"]          - Read/[Write] EPPID
        
        
SUMMARY:

    1) The commmand(H2OSDE-S) and options are NOT case-sensitive; which means that 
       the command line in upper- or lower-case is no different.

    2) If the new value is hexadecimal number, should use '0x' as prefix, or 
       append a postfix 'h' after the number (without white space between 
       them), like 0x58, or 3ah. The '0x' and 'h' are case-insnesitive. A number 
       contains with letter 'A' ~ 'F' will be treated as a hex number by default.
       
    3) To display Output Information and break when the screen is full, please
       type command with '-B' followed in command line.

       
EXAMPLES:

    1) Show DMI Information through short option
        > H2OSDE-S -SM
        
    2) Show OEM string
        a) List all OEM string
            > H2OSDE-S -OS
        b) Show Nth OEM string, N = number
            > H2OSDE-S -OS N
    
    3) Relpace DMI information string
        > H2OSDE-S -SM "new string"
        
    4) Replace DMI numeric value
        > H2OSDE-S -CT 0x0A 
        > H2OSDE-S -CT 0Ah
        > H2OSDE-S -CT 10
        
    5) Replace UUID
        > H2OSDE-S -SU 12345678-1234-1234-1234-123456789012
        
    6) Auto generate UUID
        > H2OSDE-S -SU AUTO
    
    7) Replace OEM string, N = number
        > H2OSDE-S -OS N "new OEM string"
    
    8) Show DMI Information
        a) Show all DMI Information
            > H2OSDE-S -L
        b) Show the assigned Handle
            > H2OSDE-S -L H=11
        c) Show the assigned Type
            > H2OSDE-S -L T=12   	
    
    9) Clear DMI GPNV
        > H2OSDE-S -C
    
    10) Output system event log to sysEvent.log
        > H2OSDE-S -G
        
    11) Output DMI Information to file
        a) Output all to Dmitable.txt
            > H2OSDE-S -O
        b) Output the assigned Handle to Dmitable.txt
            > H2OSDE-S -O H=11
        c) Output the assigned Type to Dmitable.txt
            > H2OSDE-S -O T=12
        d) Output all to the created file
            > H2OSDE-S -O 123.txt
        e) Output the assigned Handle to the created file
            > H2OSDE-S -O 123.txt H=11
        f) Output the assigned Type to the created file
            > H2OSDE-S -O 123.txt T=12
            
    12) Load DMI Information from file
        a) Load DMI Information from Dmitable.txt
            > H2OSDE-S -A
        b) Load DMI Information from the assigned file
            > H2OSDE-S -A 123.txt

    13) Update DMI String/UUID into Image File
	a) Update system Manufacturer string
	    > H2OSDE-S -F BIOS.fd -SM "new string"
        b) Update UUID
            > H2OSDE-S -F BIOS.fd -SU 12345678-1234-1234-1234-123456789012
        c) Auto generate UUID
            > H2OSDE-S -F BIOS.fd -SU AUTO
            
    14) To display Output Information and break when the screen is full
        > H2OSDE-S -L -B


 