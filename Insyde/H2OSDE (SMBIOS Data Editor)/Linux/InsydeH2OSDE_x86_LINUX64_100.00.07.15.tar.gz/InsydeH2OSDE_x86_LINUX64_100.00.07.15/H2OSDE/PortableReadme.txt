Portable application guide:
  
	1) build driver, please ready base compiler tool and linux kernel headers
	
		$ cd driver
		$ make
		$ cd ..
		$ cp driver/*.ko ./

