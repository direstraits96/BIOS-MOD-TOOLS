/*
 * Physical memory allocate Driver
 * File: phy_alloc.c
 *
 * Copyright(C) 2013 - 2013 Insyde Software Corp.
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/ioctl.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <asm/uaccess.h>
#include <asm/page.h>
#include <asm/io.h>
#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/types.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/fcntl.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/device.h>
#include <linux/poll.h>
#include <linux/slab.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <linux/string.h>
#include <linux/uaccess.h>

#include "phy_alloc.h"

#define Drv_VERSION "100.0.0.3"
#define DRIVER_AUTHOR "Insyde"
#define DRIVER_DESC "Insyde physical memory allocate driver"

// #define // DEBUG_MSG printk

static int gDeviceOpen = 0;
static unsigned char *gpPhysicalBuf = NULL;
static unsigned int gPhysicalBufSize = 0;
static int DrvMajor, DrvMinor;
static struct class *pDrvDevClass = NULL;
static dev_t DrvDev;

struct DrvDev_st 
{
	struct cdev cdev;
} st_DrvDev;


static int Clear_Memory(ST_PHY_ALLOC stPhyAlloc) 
{
	// DEBUG_MSG("Clear physical memory virtual address %p, size 0x%x\n", gpPhysicalBuf, gPhysicalBufSize);
	memset(gpPhysicalBuf, 0x0, gPhysicalBufSize);
	return DRV_SUCCESS;
}


static int Alloc_Physical_Memory(ST_PHY_ALLOC *pstPhyAlloc) 
{
    // DEBUG_MSG("Physical memory allocate size = 0x%x.\n", pstPhyAlloc->Size);
    gpPhysicalBuf = kmalloc( pstPhyAlloc->Size, __GFP_DMA );

	if(gpPhysicalBuf==NULL)
	{
		// DEBUG_MSG("Physical memory allocated fail.\n");
		return ALLOCATE_FAIL;
	}

	gPhysicalBufSize = pstPhyAlloc->Size;
	pstPhyAlloc->PhysicalAddress = virt_to_phys(gpPhysicalBuf);
	// DEBUG_MSG("PhysicalAddress=0x%x, VirtualAddress=%p\n",pstPhyAlloc->PhysicalAddress, gpPhysicalBuf);

    return Clear_Memory(*pstPhyAlloc);
}


static int Free_Physical_Memory(ST_PHY_ALLOC *pstPhyAlloc) 
{
	// DEBUG_MSG("Free memory %p\n", gpPhysicalBuf);
	kfree(gpPhysicalBuf);

	gpPhysicalBuf = NULL;
	gPhysicalBufSize = 0;
	pstPhyAlloc->PhysicalAddress = 0;
	pstPhyAlloc->Size = 0;

	return DRV_SUCCESS;
}

static int Drv_Open(struct inode *inode, struct file *file) 
{
	if(gDeviceOpen) 
	{
		// DEBUG_MSG("Driver had been opened\n");
		return DRV_BE_USED;
	}

	gDeviceOpen++;
	try_module_get(THIS_MODULE);

	return DRV_SUCCESS;
}

static int Drv_Release(struct inode *inode, struct file *file) 
{
	if(gDeviceOpen) 
	{
		gDeviceOpen--;
		
		if (gDeviceOpen==0)
		{
			// DEBUG_MSG("Release driver.\n");
			module_put(THIS_MODULE);
			return DRV_SUCCESS;
		}
		else
		{
			// DEBUG_MSG("Driver not last.\n");
			return DRV_BE_USED;
		}

	}
	else
	{
		// DEBUG_MSG("Driver had been release or not exist.\n");
		return DRV_SUCCESS;
	}
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION( 2, 6, 36 )
static long Drv_Ioctl(struct file *file, unsigned int num, unsigned long arg) 
{
#else
static int Drv_Ioctl(struct inode *inode, struct file *file, unsigned int num, unsigned long arg) 
{
#endif
	ST_PHY_ALLOC stPhyAlloc;
	long Ret=0;

	switch(num) 
	{

		case IOCTL_CLEAR_MEMORY:
			// DEBUG_MSG("IOCTL_CLEAR_MEMORY\n");
			if ((gpPhysicalBuf==NULL)||(gPhysicalBufSize==0))
			{
				// DEBUG_MSG("Physical memory not existing.\n");
				Ret = -1;
				break;
			}
            Ret = copy_from_user((void*)&stPhyAlloc, (void*)arg, sizeof(ST_PHY_ALLOC));
			// DEBUG_MSG("stPhyAlloc.Size= 0x%x\n", stPhyAlloc.Size);
			// DEBUG_MSG("stPhyAlloc.PhysicalAddress= 0x%x\n", stPhyAlloc.PhysicalAddress);
			Ret = Clear_Memory(stPhyAlloc);
			Ret = copy_to_user((void*)arg, (void*)&stPhyAlloc, sizeof(ST_PHY_ALLOC));
			break;

		case IOCTL_ALLOCATE_MEMORY:
			// DEBUG_MSG("IOCTL_ALLOCATE_MEMORY\n");
            Ret = copy_from_user((void*)&stPhyAlloc, (void*)arg, sizeof(ST_PHY_ALLOC));
			// DEBUG_MSG("stPhyAlloc.Size= 0x%x\n", stPhyAlloc.Size);
			// DEBUG_MSG("stPhyAlloc.PhysicalAddress= 0x%x\n", stPhyAlloc.PhysicalAddress);
			Ret = Alloc_Physical_Memory((ST_PHY_ALLOC*)&stPhyAlloc);
			Ret = copy_to_user((void*)arg, (void*)&stPhyAlloc, sizeof(ST_PHY_ALLOC));
			break;

		case IOCTL_FREE_MEMORY:
			// DEBUG_MSG("IOCTL_FREE_MEMORY\n");
			if ((gpPhysicalBuf==NULL)||(gPhysicalBufSize==0))
			{
				// DEBUG_MSG("Physical memory not existing.\n");
				Ret = -1;
				break;
			}
            Ret = copy_from_user((void*)&stPhyAlloc, (void*)arg, sizeof(ST_PHY_ALLOC));
			// DEBUG_MSG("stPhyAlloc.Size= 0x%x\n", stPhyAlloc.Size);
			// DEBUG_MSG("stPhyAlloc.PhysicalAddress= 0x%x\n", stPhyAlloc.PhysicalAddress);
			Ret = Free_Physical_Memory(&stPhyAlloc);
			Ret = copy_to_user((void*)arg, (void*)&stPhyAlloc, sizeof(ST_PHY_ALLOC));
			break;

		case IOCTL_WRITE_MEMORY:
			// DEBUG_MSG("IOCTL_WRITE_MEMORY\n");
			if ((gpPhysicalBuf==NULL)||(gPhysicalBufSize==0))
			{
				// DEBUG_MSG("Physical memory not existing.\n");
				Ret = -1;
				break;
			}
			Ret = copy_from_user((void*)gpPhysicalBuf, (void*)arg, gPhysicalBufSize);
			break;

		case IOCTL_READ_MEMORY:
			// DEBUG_MSG("IOCTL_READ_MEMORY\n");
			if ((gpPhysicalBuf==NULL)||(gPhysicalBufSize==0))
			{
				// DEBUG_MSG("Physical memory not existing.\n");
				Ret = -1;
				break;
			}
			Ret = copy_to_user((void*)arg, (void*)gpPhysicalBuf, gPhysicalBufSize);
			break;

		default:
			// DEBUG_MSG("Not found match IOCTL operate\n");
			Ret = -1;
			break;
	}

	// DEBUG_MSG("IOCTL return 0x%x(%d)\n",(unsigned int)Ret,(int)Ret);

	return Ret;
}


#if LINUX_VERSION_CODE >= KERNEL_VERSION( 2, 6, 36 )
    static DEFINE_MUTEX( drv_mutex );
    static long Drv_Ioctl_Unlock(struct file *fp, unsigned int cmd, unsigned long arg)
    {
        long            ret;
        mutex_lock( &drv_mutex );
        ret = Drv_Ioctl( fp, cmd, arg );
        mutex_unlock( &drv_mutex );
        return ret;
    }
#endif


static struct file_operations fops = {
	.open = Drv_Open,
#if LINUX_VERSION_CODE >= KERNEL_VERSION( 2, 6, 36 )
    .unlocked_ioctl = Drv_Ioctl_Unlock,
    .compat_ioctl = Drv_Ioctl_Unlock,
#else
    .ioctl = Drv_Ioctl,
#endif
	.release = Drv_Release
};


//Driver initialization
static int __init Init_Drv(void)
{
	dev_t devno = MKDEV(DrvMajor, 0);
	struct device *class_dev = NULL;

	// Alloc device driver number
	if(alloc_chrdev_region(&devno, 0, 1, DEVICE_NAME) < 0)
		return DRV_INITIAL_FAIL;
	DrvMajor = MAJOR(devno);
	DrvMinor = MINOR(devno);

	// Initial cdev
	cdev_init(&st_DrvDev.cdev, &fops);
	st_DrvDev.cdev.owner = THIS_MODULE;
	st_DrvDev.cdev.ops = &fops;

	// Regist device
	if(cdev_add(&st_DrvDev.cdev, devno, 1))
		return DRV_INITIAL_FAIL;

	// Create device node
	pDrvDevClass = class_create(THIS_MODULE, DEVICE_NAME);
	if(IS_ERR(pDrvDevClass))
		return DRV_INITIAL_FAIL;
	DrvDev = MKDEV(DrvMajor,DrvMinor);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
	class_dev = class_device_create((struct class *)pDrvDevClass,(struct class_device *)NULL, DrvDev,(struct device *)NULL, DEVICE_NAME);
#else
	class_dev = device_create(pDrvDevClass, NULL, DrvDev, NULL, DEVICE_NAME);
#endif
	// DEBUG_MSG("Initial driver success\n");
	return DRV_SUCCESS;
}

static void __exit Cleanup_Drv(void)
{
	// Destroy device node
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,36)
	class_device_destroy(pDrvDevClass, DrvDev);
#else
	device_destroy(pDrvDevClass, DrvDev);
#endif
	class_destroy(pDrvDevClass);

	// unregist device
	cdev_del(&st_DrvDev.cdev);

	// Release device number
	unregister_chrdev_region(MKDEV(DrvMajor, 0), 1);
	// DEBUG_MSG("Cleanup driver success\n");
}

module_init( Init_Drv);
module_exit( Cleanup_Drv);

MODULE_AUTHOR( DRIVER_AUTHOR );
MODULE_DESCRIPTION( DRIVER_DESC );
MODULE_VERSION( Drv_VERSION );
MODULE_SUPPORTED_DEVICE( "Insyde" );
MODULE_LICENSE( "GPL" );
