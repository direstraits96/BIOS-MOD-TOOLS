Insyde Logo Replace Tool for DOS/UEFI-SHELL

H2OLRT is a compact software that supports BIOS logo replacement and version change.

